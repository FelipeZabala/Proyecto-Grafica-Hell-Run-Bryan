#include <assimp/cimport.h> // C importer
#include <assimp/scene.h> // collects data
#include <assimp/postprocess.h> // various extra operations
#include <GL/glew.h> // include GLEW and new version of GL on Windows
#include <GLFW/glfw3.h> // GLFW helper library
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#define _USE_MATH_DEFINES
#include <math.h>
#include <string>
#include "maths_funcs.h"
#include "gl_utils.h"
#include "tools.h"
#include "malla.h"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "stb_image.h"

#define GL_LOG_FILE "log/gl.log"
#define VERTEX_SHADER_FILE "shaders/test_vs.glsl"
#define FRAGMENT_SHADER_FILE "shaders/test_fs.glsl"
#define ONE_DEG_IN_RAD (2.0 * M_PI) / 360.0 // 0.017444444
#define SKYBOX_VERTEX_SHADER_FILE "shaders/sky_vert.glsl"
#define SKYBOX_FRAGMENT_SHADER_FILE "shaders/sky_frag.glsl"
// keep track of window size for things like the viewport and the mouse cursor
int g_gl_width = 1280;
int g_gl_height = 720;
GLFWwindow* g_window = NULL;

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void input(GLFWwindow *window);
bool load_cube_map_side( GLuint texture, GLenum side_target, const char *file_name ) {
	
	glBindTexture( GL_TEXTURE_CUBE_MAP, texture );

	int x, y, n;
	int force_channels = 4;
	unsigned char *image_data = stbi_load( file_name, &x, &y, &n, force_channels );
	if ( !image_data ) {
		fprintf( stderr, "ERROR: could not load %s\n", file_name );
		return false;
	}
	// non-power-of-2 dimensions check
	if ( ( x & ( x - 1 ) ) != 0 || ( y & ( y - 1 ) ) != 0 ) {
		fprintf( stderr, "WARNING: image %s is not power-of-2 dimensions\n", file_name );
	}

	// copy image data into 'target' side of cube map
	glTexImage2D( side_target, 0, GL_RGBA, x, y, 0, GL_RGBA, GL_UNSIGNED_BYTE, image_data );
	free( image_data );
	return true;
}
// camera
glm::vec3 cameraPos   = glm::vec3(0.0f, 5.0f, 22.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp    = glm::vec3(0.0f, 1.0f, 0.0f);

//variables
float yaw   = -90.0f;	// yaw is initialized to -90.0 degrees since a yaw of 0.0 results in a direction vector pointing to the right so we initially rotate a bit to the left.
float pitch =  0.0f;
float lastX =  g_gl_width / 2.0;
float lastY =  g_gl_height / 2.0;
float fov   =  45.0f;
float x=0.0f;
float t=0.0f;
float z=-96.0f;
float z1=0.0f; 
float z2=144.0f;
float ztrampa=0.0f;
float vel=1.0f;
// timing
float deltaTime = 0.0f;	// time between current frame and last frame
float lastFrame = 0.0f;
int tramp=0;//funciona como booleano
malla *personaje;

void init(){
	restart_gl_log ();
	start_gl ();
	glEnable (GL_DEPTH_TEST); // enable depth-testing
	glDepthFunc (GL_LESS); // depth-testing interprets a smaller value as "closer"
	glEnable (GL_CULL_FACE); // cull face
	glCullFace (GL_BACK); // cull back face
	glFrontFace (GL_CCW); // set counter-clock-wise vertex order to mean the front
	glClearColor (0.2, 0.8, 0.8, 1.0); // grey background to help spot mistakes
	glViewport (0, 0, g_gl_width, g_gl_height);
	glfwSetFramebufferSizeCallback(g_window, framebuffer_size_callback);
	
}

void dibujar(malla *e1,float x, float y,float z){
	e1->reset_matrix();
	e1->mtranslate(vec3 (x,y,z));
        e1->render_indices();
}
float cambioPista(float posicion){
	if(posicion<-144.0f){ //cambio de la pista 1 a posicion inicial
		posicion=144.0f;
  	}
	return posicion;
}

int main(){
    	init();
	//inicio skybox
	float points[] = {
		-50.0f, 50.0f,	-50.0f, -50.0f, -50.0f, -50.0f, 50.0f,	-50.0f, -50.0f,
		50.0f,	-50.0f, -50.0f, 50.0f,	50.0f,	-50.0f, -50.0f, 50.0f,	-50.0f,

		-50.0f, -50.0f, 50.0f,	-50.0f, -50.0f, -50.0f, -50.0f, 50.0f,	-50.0f,
		-50.0f, 50.0f,	-50.0f, -50.0f, 50.0f,	50.0f,	-50.0f, -50.0f, 50.0f,

		50.0f,	-50.0f, -50.0f, 50.0f,	-50.0f, 50.0f,	50.0f,	50.0f,	50.0f,
		50.0f,	50.0f,	50.0f,	50.0f,	50.0f,	-50.0f, 50.0f,	-50.0f, -50.0f,

		-50.0f, -50.0f, 50.0f,	-50.0f, 50.0f,	50.0f,	50.0f,	50.0f,	50.0f,
		50.0f,	50.0f,	50.0f,	50.0f,	-50.0f, 50.0f,	-50.0f, -50.0f, 50.0f,

		-50.0f, 50.0f,	-50.0f, 50.0f,	50.0f,	-50.0f, 50.0f,	50.0f,	50.0f,
		50.0f,	50.0f,	50.0f,	-50.0f, 50.0f,	50.0f,	-50.0f, 50.0f,	-50.0f,

		-50.0f, -50.0f, -50.0f, -50.0f, -50.0f, 50.0f,	50.0f,	-50.0f, -50.0f,
		50.0f,	-50.0f, -50.0f, -50.0f, -50.0f, 50.0f,	50.0f,	-50.0f, 50.0f
	};
	GLuint vbosky;
	glGenBuffers( 1, &vbosky );
	glBindBuffer( GL_ARRAY_BUFFER, vbosky );
	glBufferData( GL_ARRAY_BUFFER, 3 * 36 * sizeof( GLfloat ), &points,
								GL_STATIC_DRAW );

	GLuint vaosky;
	glGenVertexArrays( 1, &vaosky );
	glBindVertexArray( vaosky );
	glEnableVertexAttribArray( 0 );
	glBindBuffer( GL_ARRAY_BUFFER, vbosky );
	glVertexAttribPointer( 0, 3, GL_FLOAT, GL_FALSE, 0, NULL );
	//fin skybox
		
	GLuint shader_programme = create_programme_from_files ( VERTEX_SHADER_FILE, FRAGMENT_SHADER_FILE);

    	malla *suelo = new malla((const char*)"mallas/piso.obj", shader_programme, GL_TRIANGLES);
	malla *godrox = new malla((const char*)"mallas/Godrox.obj", shader_programme, GL_TRIANGLES);
	personaje = new malla((const char*)"mallas/personaje.obj", shader_programme, GL_TRIANGLES);
    	suelo->load_texture("textures/lava.jpg");
	malla *piso = new malla((const char*)"mallas/piso1_lava.obj", shader_programme, GL_TRIANGLES);
	malla *piso2 = new malla((const char*)"mallas/piso1_lava.obj", shader_programme, GL_TRIANGLES);
	malla *roca1 = new malla((const char*)"mallas/roca1_text.obj", shader_programme, GL_TRIANGLES);
	malla *roca2 = new malla((const char*)"mallas/roca2_text.obj", shader_programme, GL_TRIANGLES);
	malla *trampa = new malla((const char*)"mallas/trampa1_text.obj", shader_programme, GL_TRIANGLES);
	piso->load_texture("textures/lavaCamino.jpg");
	piso2->load_texture("textures/lavaCamino.jpg");
	roca1->load_texture("textures/piedra.jpg");
	roca2->load_texture("textures/piedra.jpg");
	trampa->load_texture("textures/trampa.jpg");    

	glm::mat4 projection = glm::perspective(glm::radians(fov), (float)g_gl_width / (float)g_gl_height, 0.1f, 100.0f);
	glm::mat4 view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);

	int view_mat_location = glGetUniformLocation (shader_programme, "view");
	glUseProgram (shader_programme);
	glUniformMatrix4fv(view_mat_location, 1, GL_FALSE, &view[0][0]);
	int proj_mat_location = glGetUniformLocation (shader_programme, "proj");
	glUseProgram (shader_programme);
	glUniformMatrix4fv (proj_mat_location, 1, GL_FALSE, &projection[0][0]);

	//inicio skybox

	GLuint skybox_shader = create_programme_from_files ( SKYBOX_VERTEX_SHADER_FILE, SKYBOX_FRAGMENT_SHADER_FILE);
	glUseProgram (skybox_shader);

	int view_skybox = glGetUniformLocation (skybox_shader, "view");
	int proj_skybox = glGetUniformLocation (skybox_shader, "proj");
	glUniformMatrix4fv (view_skybox, 1, GL_FALSE, &view[0][0]);
	glUniformMatrix4fv (proj_skybox, 1, GL_FALSE, &projection[0][0]);



	GLuint cube_map_texture;
	glActiveTexture( GL_TEXTURE0 );
	glGenTextures( 1, &cube_map_texture );

	 load_cube_map_side( cube_map_texture, GL_TEXTURE_CUBE_MAP_POSITIVE_Z, "textures/hell/front.tga" );
	 load_cube_map_side( cube_map_texture, GL_TEXTURE_CUBE_MAP_NEGATIVE_Z, "textures/hell/back.tga"  );
	 load_cube_map_side( cube_map_texture, GL_TEXTURE_CUBE_MAP_POSITIVE_Y, "textures/hell/up.tga" ) ;
	 load_cube_map_side( cube_map_texture, GL_TEXTURE_CUBE_MAP_NEGATIVE_Y, "textures/hell/down.tga"  );
	 load_cube_map_side( cube_map_texture, GL_TEXTURE_CUBE_MAP_NEGATIVE_X, "textures/hell/right.tga" ) ;
	 load_cube_map_side( cube_map_texture, GL_TEXTURE_CUBE_MAP_POSITIVE_X, "textures/hell/left.tga" ) ;

	glTexParameteri( GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
	glTexParameteri( GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
	glTexParameteri( GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE );
	glTexParameteri( GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE );
	glTexParameteri( GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE );
	//fin skybox	
	while (!glfwWindowShouldClose (g_window)) {
		// per-frame time logic
		// --------------------
		float currentFrame = glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;
		// input
		// -----
		input(g_window);
		// render
		// ------
		glClearColor(0.2f, 0.05f, 0.05f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

                //skybox
		glUseProgram (skybox_shader);
		glDepthMask( GL_FALSE );
		glUseProgram( skybox_shader );
		glActiveTexture( GL_TEXTURE0 );
		glBindTexture( GL_TEXTURE_CUBE_MAP, cube_map_texture );
		glBindVertexArray( vaosky );
		glDrawArrays( GL_TRIANGLES, 0, 36 );
		glDepthMask( GL_TRUE );
              
		// activate shader
		glUseProgram (shader_programme);

		// pass projection matrix to shader (note that in this case it could change every frame)
		projection = glm::perspective(glm::radians(fov), (float)g_gl_width / (float)g_gl_height, 0.1f, 100.0f);
		glUniformMatrix4fv (proj_mat_location, 1, GL_FALSE, &projection[0][0]);

		// camera/view transformation
		view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
		glUniformMatrix4fv(view_mat_location, 1, GL_FALSE, &view[0][0]);


		z+=0.05f*vel; //velocidad en z
		z1-=0.1f; //posicion en z1 pista1
		z2-=0.1f; //posicion en z2 pista2
		z1=cambioPista(z1);//cambio de la pista 1 a posicion inicial
		z2=cambioPista(z2);//cambio de la pista 2 a posicion inicial
		ztrampa-=0.1f;//se mueve la trampa con la pista
		if(tramp>0){
			dibujar(trampa,0.0f,-2.01f,ztrampa);
			//reducirVelocidad();
			if(ztrampa>z-12){//12 por el ancho de a trampa
				vel=0.1;// reduce la velocidad 			
			}
			else
				vel=1; //velocidad normal
		}
		if(z<-3.0){ //godrox avanza hasta posicionarse detras del brayan
			if(x<4 && x>-4){
				dibujar(godrox,x+0.5f,-2.0f,z);
				t=x+0.5f; //variable t para que avance godrox cuando este en los bordes de la pista
			}
			else{  //cuando  ya alcanza a brayan
				dibujar(godrox,t,-2.0f,z);
			}			
			//hoz(){
				//} metodo a implementar para que godrox realice un ataque con la hoz
		}
		else{
			dibujar(godrox,t,-2.0f,-3.0);		
		}
        // render caja
		dibujar(personaje,x,-1.0f,0.0f);
        	dibujar(suelo,0.0f,-4.0f,-12.0f);
		dibujar(roca1,-22.0f,-8.0f,-32.0f);
		dibujar(roca2,22.0f,-4.0f,-32.0f);
		dibujar(piso,0,-1,z1);//se mueven las pistas infinitamente z1,z2 variables se borró metodo mover pista
		dibujar(piso2,0.0f,-1.0f,z2);
		// update other events like input handling 
		glfwPollEvents();
		// put the stuff we've been drawing onto the display
		glfwSwapBuffers (g_window);
		glfwPollEvents();
	}
	// close GL context and any other GLFW resources
	glfwTerminate();

	return 0;
}

void input(GLFWwindow *window){
	float cameraSpeed = 2.5 * deltaTime;
	if (glfwGetKey (g_window, GLFW_KEY_A) && x>-7 && z<-3.0) { //permite mover a brayan a la izquierda hasta que godrox lo alcance
		x-=0.05;
		cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;//para que la camara se quede con brayan
	}
        if (glfwGetKey (g_window, GLFW_KEY_D) && x<7 && z<-3.0) { //permite mover a brayan a la izquierda hasta que godrox lo alcance
		x+=0.05;
		cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
	}
    	if (glfwGetKey (g_window, GLFW_KEY_S)) { //activa trampa
		tramp=1;				
		ztrampa=z+4;
	}
    	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
       	 	glfwSetWindowShouldClose(window, true);
}
// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height){
    // make sure the viewport matches the new window dimensions; note that width and
    // height will be significantly larger than specified on retina displays.
    glViewport(0, 0, width, height);
}
